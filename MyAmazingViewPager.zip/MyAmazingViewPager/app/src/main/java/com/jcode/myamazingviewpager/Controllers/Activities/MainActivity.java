package com.jcode.myamazingviewpager.Controllers.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.net.Uri;
import android.os.Bundle;

import com.jcode.myamazingviewpager.Controllers.Fragments.PageFragment;
import com.jcode.myamazingviewpager.Controllers.Fragments.PageFragment.OnFragmentInteractionListener;
import com.jcode.myamazingviewpager.Models.PageAdapter;
import com.jcode.myamazingviewpager.R;

public class MainActivity extends AppCompatActivity implements OnFragmentInteractionListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		//3 - Configure ViewPager
		this.configureViewPager();
	}

	private void configureViewPager(){
		// 1 - Get ViewPager from layout
		ViewPager pager = (ViewPager)findViewById(R.id.activity_main_viewpager);
		// 2 - Set Adapter PageAdapter and glue it together
		pager.setAdapter(new PageAdapter(getSupportFragmentManager(), getResources().getIntArray(R.array.colorPagesViewPager)) {
		});
	}

	@Override
	public void onFragmentInteraction(Uri uri) {
		//TODO Add something here
	}
}
