package com.jcode.myamazingviewpager.Models;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.jcode.myamazingviewpager.Controllers.Fragments.PageFragment;

/**
 * Created by otimj on 9/6/2019.
 */
//FragmentStatePagerAdapter: This adapter will NOT keep all of the pages displayed in memory (fragments) after they are created.
// Imagine that you're developing an ebook reader app containing 1000 page:: You can't keep them all in memory!
// This adapter will therefore be tasked with creating/deleting them on the fly (it will only keep 3 in memory), thereby optimizing your app's performance.
//
//FragmentPagerAdapter: This adapter will keep in memory all of the pages displayed (fragments) after they are created.
// This will enable greater fluidity when swiping and displaying them, particularly if the user needs to keep coming and going.
// Be careful, however, with the complexity and content of these pages and how many of them there are, to avoid overloading the memory.

//public class PageAdapter extends FragmentStatePagerAdapter {
public class PageAdapter extends FragmentPagerAdapter {
	// 1 - Array of colors that will be passed to PageFragment
	private int[] colors;

	// 2 - Default Constructor
	public PageAdapter(FragmentManager mgr, int[] colors) {
		super(mgr);
		this.colors = colors;
	}

	@Override
	public int getCount() {
		return(5); // 3 - Number of page to show
	}

	@Override
	public Fragment getItem(int position) {
		// 4 - Page to return
		return(PageFragment.newInstance(position, this.colors[position]));
	}
}

